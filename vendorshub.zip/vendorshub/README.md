VendorsHub - Indian Small Business Review Platform
A complete full-stack review platform for Indian small businesses built with Flask and TailwindCSS.

🎯 Features
✅ Dual Authentication System
Vendor Accounts: Create and manage business listings
Customer Accounts: Write and view reviews
✅ Vendor Features
Create business profile (India-based only with state validation)
Upload business images
View comprehensive analytics dashboard
Monitor customer reviews in real-time
Edit business information
✅ Customer Features
Interactive star rating system (1-5 stars)
Structured review submission:
Hygiene rating
Basic necessities availability (Yes/No)
Staff behavior rating
Pricing fairness rating
Overall rating
Written feedback
Photo upload
Interactive review filtering:
Filter by hygiene score
Filter by staff rating
Filter by pricing
Filter by necessities availability
Dynamic sorting:
Most recent
Highest rated
Lowest rated
Live review preview before submission
✅ Public Features
Search vendors by name, category, or city
Browse top-rated Indian vendors
View recently reviewed businesses
Responsive mobile-friendly design
📁 Project Structure
vendorshub/
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── vendorshub.db          # SQLite database (auto-created)
├── static/
│   └── uploads/           # User-uploaded images
└── templates/
    ├── base.html          # Base template
    ├── index.html         # Home page
    ├── login.html         # Login page
    ├── register.html      # Registration page
    ├── vendor_dashboard.html    # Vendor dashboard
    ├── create_vendor.html       # Create business form
    ├── edit_vendor.html         # Edit business form
    ├── vendor_profile.html      # Public vendor profile
    └── review_form.html         # Interactive review form
🚀 Installation & Setup
Step 1: Prerequisites
Python 3.8 or higher
pip (Python package manager)
Step 2: Create Project Directory
bash
mkdir vendorshub
cd vendorshub
Step 3: Create Virtual Environment (Recommended)
bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
Step 4: Install Dependencies
bash
pip install -r requirements.txt
Step 5: Create Directory Structure
bash
# Create necessary directories
mkdir -p static/uploads
mkdir -p templates
Step 6: Add All Template Files
Copy all the HTML template files into the templates/ directory:

base.html
index.html
login.html
register.html
vendor_dashboard.html
create_vendor.html
edit_vendor.html
vendor_profile.html
review_form.html
Step 7: Run the Application
bash
python app.py
The application will:

Automatically create the SQLite database (vendorshub.db)
Set up all required tables
Start the development server
Step 8: Access the Application
Open your browser and navigate to:

http://127.0.0.1:5000
👥 User Workflows
For Vendors:
Register → Choose "Vendor" role
Login with your credentials
Create Business Listing:
Select Indian state (required)
Enter city, category, description
Upload business image
View Dashboard to see analytics and reviews
Share your profile link with customers
For Customers:
Register → Choose "Customer" role
Login with your credentials
Browse vendors on home page or use search
Click on a vendor to view their profile
Write a review:
Click interactive stars to rate (1-5)
Answer structured questions
Add written feedback (optional)
Upload photos (optional)
See live preview before submitting
🎨 Design Features
Modern UI Elements:
✨ Purple & Teal gradient theme
🎯 Interactive hover effects on cards
⭐ Animated star rating components
📱 Fully responsive mobile design
🎭 Smooth transitions and animations
🖼️ Image upload and display
📊 Visual analytics dashboard
Interactive Components:
Click-to-rate star system with hover preview
Real-time review preview
Dynamic filter panel
Instant sorting without page reload
Smooth animations on review cards
🔒 Security Features
Password hashing using Werkzeug
Flask-Login session management
Role-based access control
File upload validation
India-based vendor validation (enforced at form level)
🗄️ Database Schema
Users Table
id, name, email, password_hash, role, created_at
Vendors Table
id, user_id, business_name, category, description
state, city, address, image_path, created_at
Reviews Table
id, vendor_id, customer_id
hygiene_rating, necessities_available
staff_rating, pricing_rating, overall_rating
text, image_path, created_at
📊 Analytics
Vendors can view:

Overall average rating
Total number of reviews
Average hygiene score
Average staff behavior rating
Average pricing rating
Percentage of "necessities available"
🛠️ Customization
Change Secret Key (IMPORTANT for production):
Edit app.py:

python
app.config['SECRET_KEY'] = 'your-super-secret-key-here'
Switch to PostgreSQL:
Edit app.py:

python
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://user:password@localhost/vendorshub'
Add More Categories:
Edit the BUSINESS_CATEGORIES list in app.py

Add More States:
Edit the INDIAN_STATES list in app.py

🚨 Troubleshooting
Database Issues:
bash
# Delete and recreate database
rm vendorshub.db
python app.py  # Will auto-create new database
Upload Directory Issues:
bash
# Ensure uploads directory exists
mkdir -p static/uploads
chmod 755 static/uploads
Port Already in Use:
python
# Change port in app.py
app.run(debug=True, port=5001)
📝 Sample Data
Test Accounts:
Vendor Account:

Role: Vendor
Create business in any Indian state
Customer Account:

Role: Customer
Leave reviews for vendors
🎯 Key Technologies
Backend: Flask 3.0, SQLAlchemy, Flask-Login
Frontend: TailwindCSS 3.x, Vanilla JavaScript
Database: SQLite (development), PostgreSQL (production-ready)
Authentication: Flask-Login + Werkzeug password hashing
File Handling: Werkzeug secure filename
📄 License
This project is open-source and available for educational purposes.

🤝 Support
For issues or questions, please check:

All template files are in the templates/ directory
static/uploads/ directory exists and is writable
All dependencies are installed
Python version is 3.8 or higher
Built with ❤️ for Indian Small Businesses

